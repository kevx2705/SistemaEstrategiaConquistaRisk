package co.edu.unbosque.risk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RiskApplicationTests {

	@Test
	void contextLoads() {
	}

}
